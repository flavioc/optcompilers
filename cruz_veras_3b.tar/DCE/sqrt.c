
#include <stdio.h>
#include <math.h>
#include <stdlib.h>

int
main(int argc, char **argv)
{
   int a = argc + 1;

   int b = sqrt(2.0);

   return a;
}
